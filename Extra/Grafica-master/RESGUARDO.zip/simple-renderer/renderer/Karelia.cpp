/////////////////////////////////////////////////////////////////////
///       KARELIA ALEXANDRA VILCA SALINAS                         ///
///       CCOMP 8-1                                               ///
/////////////////////////////////////////////////////////////////////

#include <math.h>
using namespace std;
/////CLIPPING
int LEFT=1,RIGHT=2,BOTTOM=4,TOP=8,xl=0,yl=0,xh=600,yh=4000;
int aceptar=0;
int outcode(int x,int y){
    int code = 0;
    //bitwise
    if(y > yh) code |=TOP;
    if(y < yl) code |=BOTTOM;
    if(x < xl) code |=LEFT;
    if(x > xh) code |=RIGHT;
    return code;
}
pair< pair<int,int >, pair<int,int > > clipping(int x0,int y0,int x1,int y1)
{
    int outcode0=outcode(x0,y0), outcode1=outcode(x1,y1);
    ///trivial accept
    if(outcode0==0 && outcode1==0)
    { 
            aceptar = 1;
    }
    ///trivial reject
    else if((outcode0 & outcode1)!=0)
    {
            aceptar = 0;
    }
    else
    {
        int temp,x,y;
        float m =(float)(y1-y0)/(x1-x0);
        if(outcode0==0) ///primer punto adentro
            temp = outcode1;
        else
            temp = outcode0;
        if(temp & TOP)
        {
            x = x1+ (yh-y1)/m;
            y = yh;
        }
        else if(temp & BOTTOM)
        {     
            x = x1+ (yl-y1)/m;
            y = yl;
        }
        else if(temp & LEFT)
        {
            x = xl;
            y = y1+ m*(xl-x1);
        }
        else if(temp & RIGHT)
        {   
            x = xh;
            y = y1+ m*(xh-x1);
        }
        if(temp == outcode0){ 
            x0 = x;
            y0 = y;
            outcode0 = outcode(x0,y0);
        }
        else{
            x1 = x;
            y1 = y;
            outcode1 = outcode(x1,y1);
        }
    }
    return make_pair(make_pair(x0,y0),make_pair(x1,y1));
}
/////BRESENHAM
std::list <pair<int,int > > puntos;
void setPixel(int x, int y)
{
    puntos.push_back(make_pair(x,y));
}

//Dibuja la linea si la distancia de X es mayor que Y 
void bresenhamX(int x0, int y0, int x1, int y1, int dx, int dy)
{
    int i, j, k;

    i = 2 * dy - dx;
    j = 2 * dy;
    k = 2 * (dy - dx);
    if (!(x0 < x1)) 
    {
        swap(x0, x1);
        swap(y0, y1);
    }
    setPixel(x0, y0);
    while (x0 < x1) 
    {
        if (i < 0)
            i += j;
        else 
        {
            if (y0 < y1)
                ++y0;
            else
                --y0;
            i += k;
        }
        ++x0;
        setPixel(x0, y0);
    }
}

//Dibuja la linea si la distancia de X es menor que Y 
void bresenhamY(int x0, int y0, int x1, int y1, int dx, int dy)
{
    int i, j, k;

    i = 2 * dx - dy;
    j = 2 * dx;
    k = 2 * (dx - dy);
    if (!(y0 < y1)) 
    {
        swap(x0, x1);
        swap(y0, y1);
    }
    setPixel(x0, y0);
    while (y0 < y1) 
    {
        if (i < 0)
            i += j;
        else 
        {
            if (x0 > x1)
                --x0;
            else
                ++x0;
            i += k;
        }
        ++y0;
        setPixel(x0, y0);
    }
}

//Llamara a la funcion apropiada dependiendo de la longitud de los ejes x y y 
list <pair<int,int > >  bresenham(int x0, int y0, int x1, int y1)
{
    pair< pair<int,int >, pair<int,int > > l=clipping(x0,y0,x1,y1);
    if(aceptar!=0)
    {
        x0=l.first.first;
        y0=l.first.second;
        x1=l.second.first;
        y1=l.second.second;
        int dx = abs(x1 - x0);
        int dy = abs(y1 - y0);

        if (dx >= dy)
            bresenhamX(x0, y0, x1, y1, dx, dy);
        else
            bresenhamY(x0, y0, x1, y1, dx, dy);
    }
    return puntos;
}
////SCANLINE
std::list <pair<int,int > > relleno;
class punto
{
    public:
    int x,y;
};

class poligono
{
    private:
        punto p[4];
        int inter[4],x,y;
        int v,xmin,ymin,xmax,ymax;
    public:

        int c;
        void leer( list < vector<2> >);
        void maxmin();
        void display();
        void ints(float);
        void pintar(int);
};


void poligono::leer( list < vector<2> > lista)
{
    v=lista.size();
    int i=0;
    for(auto item :lista)
    {
        p[i].x=item[0];
        p[i].y=item[1];
        i++;
    } 
  
    p[v].x=p[0].x;
    p[v].y=p[0].y;
  
    xmin=xmax=p[0].x;
    ymin=ymax=p[0].y;

}

void poligono::maxmin()
{ 
    for(int i=0;i<v;i++)
    {
        if(xmin>p[i].x)
        xmin=p[i].x;
        if(xmax<p[i].x)
        xmax=p[i].x;
        if(ymin>p[i].y)
        ymin=p[i].y;
        if(ymax<p[i].y)
        ymax=p[i].y;
    }
}

void poligono::display()
{
    
    float s;
    s=ymin+0.01;
    while(s<=ymax)
    { 
        ints(s);
        pintar(s);//s =y
        s+=1;
    } 
    
}

void poligono::ints(float z) 
{
    int x1,x2,y1,y2;
    c=0;
    for(int i=0;i<v;i++)
    {
        x1=p[i].x;
        y1=p[i].y;
        x2=p[i+1].x;
        y2=p[i+1].y;
        if(y2<y1)//solo sentido
        {
            swap(x1, x2);
            swap(y1, y2);
        }
        if(z<=y2&&z>=y1)
        {
            if((y1-y2)==0)
                x=x1;
            else 
            {
                x=((x2-x1)*(z-y1))/(y2-y1);/// inclinacion con z
                x=x+x1;
            }
            if(x<=xmax && x>=xmin)
                inter[c++]=x;
        }
    }
}

void poligono::pintar(int z) 
{
    for(int i=0; i<c;i+=2)
    {            
        list <pair<int,int > > a = bresenham(inter[i],z,inter[i+1],z);  
        for( auto item : a )
            relleno.push_back(item);
    }
}

list <pair<int,int > >  Scan_Line( list < vector<2> > lista) 
{   relleno.clear();
    poligono x;
    x.leer(lista);
    x.maxmin();
    x.display();
    return relleno;
}
float f (vector<2> a, vector<2> b,vector<2> p)
{//f_{ab}(x,y)=(y_a - y_b)x + (x_b - x_a)y + x_a y_b - x_b y_a; a,b \in {0,1,2}  
  float res=(a[1]-b[1])*p[0]+(b[0]-a[0])*p[1]+a[0]*b[1]-b[0]*a[1]+0.000000001;
  return res;
}
vector<3> interpolacion(vector<2> p0, vector<2> p1, vector<2> p2,vector<2> p)
{
    vector<3> resultado;
    resultado[0]=f(p1,p2,p)/f(p1,p2,p0);
    resultado[1]=f(p2,p0,p)/f(p2,p0,p1);
    resultado[2]=f(p0,p1,p)/f(p0,p1,p2);
    //cout<<"HERE: "<< resultado[0]<<" , "<< resultado[1]<<" , "<< resultado[2]<<" = "<< resultado[0]+resultado[1]+resultado[2] <<endl;
    return resultado;
}
vector<4> multiplicacion_mat_vec(vector<4> vec, float mat[4][4])
{
    vector<4> solucion;
   
    for (int i=0;i<4;i++)///pintar lo que esta en relleno
    {  
        float acum=0;
        for(int j=0;j<4;j++)
        {
            acum+=vec[i]*mat[j][i];
        }
        solucion[i]=acum;
    } 
    return solucion;  

}
/*void my_PerspectiveFOV(double fov, double aspect, double near, double far, double* mret) {
    double D2R = M_PI / 180.0;
    double yScale = 1.0 / tan(D2R * fov / 2);
    double xScale = yScale / aspect;
    double nearmfar = near - far;
    double m[] = {
        xScale, 0, 0, 0,
        0, yScale, 0, 0,
        0, 0, (far + near) / nearmfar, -1,
        0, 0, 2*far*near / nearmfar, 0 
    };
}*/
matrix<4, 4> perspective(unsigned short Width,unsigned short Height, 
    unsigned short zNear,unsigned short zFar,unsigned short FOV ,double dist) 
{
    unsigned short ar = Width / Height;
    unsigned short zRange = zNear - zFar;
    double tanHalfFOV =/* 1/dist;*/tanf((FOV / 2.0)*3.14/180);
    //cout<<"valores"<<ar<<" "<<zRange<<" "<<tanHalfFOV<<" "<<dist<<endl;
    matrix<4, 4> m;
    m[0][0] = 1.0f / (tanHalfFOV * ar); 
    m[0][1] = 0.0f;
    m[0][2] = 0.0f;
    m[0][3] = 0.0f;

    m[1][0] = 0.0f;
    m[1][1] = 1.0f / tanHalfFOV; 
    m[1][2] = 0.0f; 
    m[1][3] = 0.0f;

    m[2][0] = 0.0f; 
    m[2][1] = 0.0f; 
    m[2][2] = (-zNear - zFar) / zRange; 
    m[2][3] = 2.0f * zFar * zNear / zRange;

    m[3][0] = 0.0f;
    m[3][1] = 0.0f; 
    m[3][2] = 1.0f; 
    m[3][3] = 0.0f;
    return m;
}
float angulo(vector<3>u,vector<3>v)//radianes
{
    return acos((u[0]*v[0]+u[1]*v[1]+u[2]*v[2])/
                (sqrt(u[0]*u[0]+u[1]*u[1]+u[2]*u[2])*
                sqrt(v[0]*v[0]+v[1]*v[1]+v[2]*v[2])));
}
vector<3> normalizar(vector<3>_vector)
{
    float square = sqrt((_vector[0]*_vector[0]) + (_vector[1]*_vector[1]) + (_vector[2]*_vector[2]));
    vector<3> normalized; 
    normalized[0] = (_vector[0] / square); 
    normalized[1] =(_vector[1] / square); 
    normalized[2] = (_vector[2] / square);
    return normalized;
}
float phong(float Isa,float Ka,float Isd,float Kd,float theta, float Iss,float Ks, float a, int n)
{
    float I=0;
    I+=Isa*Ka;                        ///ambiente
    I+=Isd*Kd*theta;//cos(theta* 3.15 / 180.0); ///difusa
    I+=Iss*Ks*pow(a,n);     //cos(a)     ///especular
    return I;
}
vector<3> reflection(vector<3>n,vector<3>l )
{
    float escalar = (n[0]*l[0] + n[1]*l[1] + n[2]*l[2]) * 2; //Produncto punto de n * l = escalar    
    vector<3> r ; r[0] = escalar * (n[0] - l[0]); r[1] = escalar * (n[1] - l[1]); r[2] = escalar * (n[2] - l[2]);
    return r;
}
vector<3> phong3(vector<4> v1,vector<4> v2,vector<4> v3,vector<3> luz,vector<3> camara,vector<3>Isa,vector<3> Ka,
    vector<3>Isd,vector<3>Kd,vector<3>Iss,vector<3>Ks,int n)
{
    vector<4> dif1=v1-v2;
    vector<4> dif2=v3-v2;
    vector<3> normal;
    normal[0]=dif1[1]*dif2[2]-dif1[2]*dif2[1];
    normal[1]=dif1[2]*dif2[0]-dif1[0]*dif2[2];
    normal[2]=dif1[0]*dif2[1]-dif1[1]*dif2[0];
    normal=normalizar(normal);
    luz=normalizar(luz);
    float theta=luz*normal;
    // vector<3>  a=angulo(luz, camara)-2*theta;
    vector<3> reflexion = reflection(normal,luz);
    vector<3> view = normalizar(camara);
    float specular =reflexion*view;

    vector<3> Irgb;
    Irgb[0]=phong(Isa[0],Ka[0],Isd[0],Kd[0],theta,Iss[0],Ks[0],specular,n);
    Irgb[1]=phong(Isa[1],Ka[1],Isd[1],Kd[1],theta,Iss[1],Ks[1],specular,n);
    Irgb[2]=phong(Isa[2],Ka[1],Isd[2],Kd[2],theta,Iss[2],Ks[2],specular,n);
    
    return Irgb;
}
/*
#include <math.h>
using namespace std;

list <pair<int,int > > puntos;
void setPixel(int x, int y)
{
    puntos.push_back(make_pair(x,y));
}

//Dibuja la linea si la distancia de X es mayor que Y 
void bresenhamX(int x0, int y0, int x1, int y1, int dx, int dy)
{
    int i, j, k;

    i = 2 * dy - dx;
    j = 2 * dy;
    k = 2 * (dy - dx);
    if (!(x0 < x1)) 
    {
        swap(x0, x1);
        swap(y0, y1);
    }
    setPixel(x0, y0);
    while (x0 < x1) 
    {
        if (i < 0)
            i += j;
        else 
        {
            if (y0 < y1)
                ++y0;
            else
                --y0;
            i += k;
        }
        ++x0;
        setPixel(x0, y0);
    }
}

//Dibuja la linea si la distancia de X es menor que Y 
void bresenhamY(int x0, int y0, int x1, int y1, int dx, int dy)
{
    int i, j, k;

    i = 2 * dx - dy;
    j = 2 * dx;
    k = 2 * (dx - dy);
    if (!(y0 < y1)) 
    {
        swap(x0, x1);
        swap(y0, y1);
    }
    setPixel(x0, y0);
    while (y0 < y1) 
    {
        if (i < 0)
            i += j;
        else 
        {
            if (x0 > x1)
                --x0;
            else
                ++x0;
            i += k;
        }
        ++y0;
        setPixel(x0, y0);
    }
}

//Llamara a la funcion apropiada dependiendo de la longitud de los ejes x y y 
list <pair<int,int > >  bresenham(int x0, int y0, int x1, int y1)
{
    int dx = abs(x1 - x0);
    int dy = abs(y1 - y0);

    if (dx >= dy)
        bresenhamX(x0, y0, x1, y1, dx, dy);
    else
        bresenhamY(x0, y0, x1, y1, dx, dy);
    return puntos;
}
////SCANLINE
list <pair<int,int > > relleno;
class punto
{
    public:
    int x,y;
};

class poligono
{
    private:
        punto p[4];
        int inter[4],x,y;
        int v,xmin,ymin,xmax,ymax;
    public:
        int c;
        void leer( list < vector<2> >);
        void maxmin();
        void display();
        void ints(float);
        void pintar(int);
};


void poligono::leer( list < vector<2> > lista)
{
    v=lista.size();
    int i=0;
    for(auto item :lista)
    {
        p[i].x=item[0];
        p[i].y=item[1];
        i++;
    } 

    p[v].x=p[0].x;
    p[v].y=p[0].y;
  
    xmin=xmax=p[0].x;
    ymin=ymax=p[0].y;

}

void poligono::maxmin()
{ 
    for(int i=0;i<v;i++)
    {
        if(xmin>p[i].x)
        xmin=p[i].x;
        if(xmax<p[i].x)
        xmax=p[i].x;
        if(ymin>p[i].y)
        ymin=p[i].y;
        if(ymax<p[i].y)
        ymax=p[i].y;
    }
}

void poligono::display()
{
    
    float s;
    s=ymin+0.01;
    while(s<=ymax)
    { 
        ints(s);
        pintar(s);
        s+=10;
    }
    
}

void poligono::ints(float z) 
{
    int x1,x2,y1,y2;
    c=0;
    for(int i=0;i<v;i++)
    {
        x1=p[i].x;
        y1=p[i].y;
        x2=p[i+1].x;
        y2=p[i+1].y;
        if(y2<y1)
        {
            swap(x1, x2);
            swap(y1, y2);
        }
        if(z<=y2&&z>=y1)
        {
            if((y1-y2)==0)
                x=x1;
            else 
            {
                x=((x2-x1)*(z-y1))/(y2-y1);/// inclinacion con z
                x=x+x1;
            }
            if(x<=xmax && x>=xmin)
                inter[c++]=x;
        }
    }
}

void poligono::pintar(int z) 
{
    for(int i=0; i<c;i+=2)
    {            
        list <pair<int,int > > a = bresenham(inter[i],z,inter[i+1],z);  
        for( auto item : a )
            relleno.push_back(item);
    }
}

list <pair<int,int > >  Scan_Line( list < vector<2> > lista) 
{
    poligono x;
    x.leer(lista);
    x.maxmin();
    x.display();
    return relleno;
}
*/