#include "renderer/engine.h"
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <algorithm>
using namespace std;
std::vector<string> vertices;
std::vector<unsigned int> vertexIndices;
void cargarOBJ(std::string archivo) {
    ifstream file = ifstream(archivo);
    if (!file.is_open()) {
        cout << "No se ecuentra: " << archivo << endl;
    }
    //int count = 0;
    
	ofstream ficheroSalida;
    ficheroSalida.open ("./data/karelia.scn");
    string aux=""; 
    /////CABECERA/////////////////////////////////////////////////////////
    ficheroSalida<<"[background]\n";
	ficheroSalida<<"\trgb 	1.0	1.0	1.0\n";
    ficheroSalida<<"[/background]\n";

    ficheroSalida<<"[camera]\n";
	ficheroSalida<<"\tpos 	0.0	0.0	20.0\n";
	ficheroSalida<<"\tdir 	0.0	0.0 1.0\n";
	ficheroSalida<<"\tup 		0.0	1.0	0.0\n";
	ficheroSalida<<"\tfovy	60.0\n";
    ficheroSalida<<"[/camera]\n";

    ficheroSalida<<"[light]\n";
	ficheroSalida<<"\tname 	ambient\n";
	ficheroSalida<<"\trgb 	0.5	0	0\n";
    ficheroSalida<<"[/light]\n";
 
    ficheroSalida<<"[transformation]\n";
	ficheroSalida<<"\tname 	translate\n";
	ficheroSalida<<"\tdxdydz	0.0	0.0	-20.0\n";
	ficheroSalida<<"\t[light]\n"; 
	ficheroSalida<<"\t\tname 	point\n";
	ficheroSalida<<"\t\trgb 	1.0	1.0	1.0\n";
	ficheroSalida<<"\t[/light]\n";
    ficheroSalida<<"[/transformation]\n";

    ficheroSalida<<"[transformation]\n";
	ficheroSalida<<"\tname 	translate\n";
	ficheroSalida<<"\tdxdydz	0.0	0.0	3.0\n";

	ficheroSalida<<"\t[transformation]\n";
	ficheroSalida<<"\t\tname 	rotate\n";
	ficheroSalida<<"\t\taxis 	1	1	1\n";
	ficheroSalida<<"\t\tangle 0\n";

	ficheroSalida<<"\t\t[transformation]\n";
	ficheroSalida<<"\t\t\tname 	scale\n";
	ficheroSalida<<"\t\t\tsxsysz	2	2	2\n";  
    //////////////////////////////////////////////////////////////////////
	 while (file) {
        string linea;
        getline(file, linea);
        istringstream str(linea);
            string start;
            str >> start;
           
			float v1, v2, v3;
			

            if (start == "vt") {////cooredenadas de textura
                /*str >> v1 >> v2;
                temp_uv.push_back(glm::vec2(v1, v2));*/
            }
            else if (start == "vn") {///normal en sus 3 componentes
                /*str >> v1 >> v2 >> v3;
                temp_normal.push_back(glm::vec3(v1, v2, v3));*/
            }
			else if (start == "v") {////cooredenadas
                // cout<<"-> "<<start<<i<<endl;
                str >> v1 >> v2 >> v3;
                std::ostringstream ss;std::ostringstream ss2;std::ostringstream ss3;
                ss << v1;
				ss2 << v2;
				ss3 << v3;
				aux=ss.str()+" "+ ss2.str()+" "+ss3.str()+"		";
                vertices.push_back(aux);
            }
            else if (start == "f") {//establece los índices de vértices/textura/normal requeridos para formar cada uno de los triángulos que componen el modelo 3D.
                 unsigned int v1, v2, v3, n1, n2, n3, uv1, uv2, uv3;

                // reemplazar el caracter "/" por " "
                std::replace_if(std::begin(linea), std::end(linea), [](const char& ch) { return ch == '/'; }, ' ');

                istringstream face_str(linea);
                face_str.ignore(linea.length(), ' ');

                face_str >> v1 >> uv1 >> n1 >> v2 >> uv2 >> n2 >> v3 >> uv3 >> n3;

                vertexIndices.push_back(v1);
                vertexIndices.push_back(v2);
                vertexIndices.push_back(v3);

                /*normalIndices.push_back(n1);
                normalIndices.push_back(n1);
                normalIndices.push_back(n3);

                uvIndices.push_back(uv1);
                uvIndices.push_back(uv2);
                uvIndices.push_back(uv3);*/
            }
	}
    aux="";
    for(int i=0;i<vertexIndices.size()-2;i+=3)
    {   aux=vertices[vertexIndices[i]-1]+" "+
            vertices[vertexIndices[i+1]-1]+" "+
            vertices[vertexIndices[i+2]-1];
            ficheroSalida<<"\t\t\t[object]\n\t\t\t\tname 	triangle\n";
            ficheroSalida<<"\t\t\t\tvertices\t";
            //cout<<"AUXILIAR"<<aux<<endl;
            ficheroSalida<<aux;
            ficheroSalida<<"\n";
			ficheroSalida<<"\t\t\t\trefractive	0.0\n\t\t\t\treflective	0.3\n\t\t\t\tshinniness	45\n\t\t\t\tior 	1.05\n\t\t\t\trgb	0.2	0.2	0.8\n\t\t\t[/object]\n";
			aux="";
    }
    /////FIN//////////////////////////////////////////////////////////////
    ficheroSalida<<"\t\t[/transformation]\n";
	ficheroSalida<<"\t[/transformation]\n";
    ficheroSalida<<"[/transformation]\n"; 
    ficheroSalida<<"[end]\n";
    //////////////////////////////////////////////////////////////////////
    ficheroSalida.close();
}  
//! main entry point
int main(int __argc,char **__argv)
{
    
    cargarOBJ("./data/cyborg.obj"); ///lowpolytree.obj  ////bomb.obj ///cyborg.obj
    engine _rendering_engine("./data/karelia.scn");    
	// the rendering engine     
	//engine _rendering_engine("./data/test.scn");         
    //engine _rendering_engine("./data/test-cubo2.scn");     
	// run the engine     
	return _rendering_engine.run();
}
  