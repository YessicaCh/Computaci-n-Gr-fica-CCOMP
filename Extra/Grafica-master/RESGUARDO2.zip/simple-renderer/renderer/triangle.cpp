#include <list>
#include "triangle.h"
#include "Karelia.cpp"

// constructor
triangle::triangle(matrix<4, 4>& __t, material &__material, vector<3> __v1, vector<3> __v2,
        vector<3> __v3) :
        object(__t, __material) {
    // initialize vertices
    _v1 = __v1;
    _v2 = __v2;
    _v3 = __v3;
}

// rasterize 
unsigned int lon;
vector<2> __pv1;
vector<2> __pv2; 
vector<2> __pv3;    
vector<3> luz_phongv1; 
vector<3> luz_phongv2;
vector<3> luz_phongv3;
bool triangle::rasterize(camera* __camera, unsigned short __w, unsigned short __h,
        vector<3> __ambient, dlight *__dlights, unsigned long __num_dlights, plight *__plights,
        unsigned long __num_plights, float*& __color_buffer, float*& __depth_buffer) {
    //<<TODO>> transform, lit, project, rasterize, calculate final color and depth 
    //cout<<"THIS-->"<<__w<<" "<<__h<<endl; 
    // initialize color buffer 
    lon=__w * __h * 4; 
    __color_buffer = new float[__w * __h * 4];

    // initialize depth buffer
    __depth_buffer = new float[__w * __h*4];
    
    // model transform
    vector<4> __v1;
    __v1[0] = _v1[0];
    __v1[1] = _v1[1];
    __v1[2] = _v1[2];
    __v1[3] = 1.0;
    vector<4> __v2;
    __v2[0] = _v2[0];
    __v2[1] = _v2[1];
    __v2[2] = _v2[2];
    __v2[3] = 1.0;
    vector<4> __v3;
    __v3[0] = _v3[0];
    __v3[1] = _v3[1];
    __v3[2] = _v3[2];
    __v3[3] = 1.0;
    __v1 = _t * __v1;
    __v2 = _t * __v2;
    __v3 = _t * __v3;

    // world
    matrix<4, 4> __ww;
    __ww[0][0] = __camera->right()[0];
    __ww[1][0] = __camera->right()[1];
    __ww[2][0] = __camera->right()[2];
    __ww[0][1] = __camera->up()[0];
    __ww[1][1] = __camera->up()[1];
    __ww[2][1] = __camera->up()[2];
    __ww[0][2] = __camera->dir()[0];
    __ww[1][2] = __camera->dir()[1];
    __ww[2][2] = __camera->dir()[2];

    // world transform
    __v1 = __ww * (__v1 - __camera->pos());
    __v2 = __ww * (__v2 - __camera->pos());
    __v3 = __ww * (__v3 - __camera->pos());

    // orthogonal projection
    //vector<2> __pv1;
    /*__pv1[0] = __v1[0];
    __pv1[1] = __v1[1];
    //vector<2> __pv2;
    __pv2[0] = __v2[0]; 
    __pv2[1] = __v2[1];
    //vector<2> __pv3;
    __pv3[0] = __v3[0];
    __pv3[1] = __v3[1];

    // simulating a frustrum
    __pv1[0] += 5.f;
    __pv1[0] *= __w / 10.f;
    __pv1[1] += 5.f;
    __pv1[1] *= __h / 10.f;
    __pv2[0] += 5.f;
    __pv2[0] *= __w / 10.f;
    __pv2[1] += 5.f;
    __pv2[1] *= __h / 10.f;
    __pv3[0] += 5.f;
    __pv3[0] *= __w / 10.f;
    __pv3[1] += 5.f;
    __pv3[1] *= __h / 10.f;*/
    unsigned short FOV =60;



    
    double dist= __camera->pos()[2];
    //cout<<"dis "<<dist<<endl;
    matrix<4, 4> matrix= perspective(__w,__h,1,-1,FOV,dist ) ; 
    vector<4> aux=matrix*__v1;                                                                                                                                                  //cout<<" "<<aux[0]<<" "<<aux[1]<<endl;
    __pv1[0] = (aux[0]/aux[3]+1)*__w/2;//sqrt(aux[0]*aux[0]+aux[1]*aux[1]+aux[2]*aux[2]+aux[3]*aux[3])*100000; 
    __pv1[1] = (aux[1]/aux[3]+1)*__h/2;///sqrt(aux[0]*aux[0]+aux[1]*aux[1]+aux[2]*aux[2]+aux[3]*aux[3])*100000;       
    //cout<<"a "<<aux[0]/aux[3]<<"\t"<< aux[1]/aux[3]<<endl;
    //cout<<"b "<<__pv1[0]<<"\t"<< __pv1[1]<<endl;
    aux=matrix*__v2; 
    __pv2[0] = (aux[0]/aux[3]+1)*__w/2;///sqrt(aux[0]*aux[0]+aux[1]*aux[1]+aux[2]*aux[2]+aux[3]*aux[3])*100000; 
    __pv2[1] = (aux[1]/aux[3]+1)*__h/2;///sqrt(aux[0]*aux[0]+aux[1]*aux[1]+aux[2]*aux[2]+aux[3]*aux[3])*100000;
    //                                                                                                                                              cout<<"AQUI "<<__pv2[0]<<" "<<__pv2[1]<<endl;
    aux=matrix*__v3; 
    __pv3[0] = (aux[0]/aux[3]+1)*__w/2;///sqrt(aux[0]*aux[0]+aux[1]*aux[1]+aux[2]*aux[2]+aux[3]*aux[3])*100000;
    __pv3[1] = (aux[1]/aux[3]+1)*__h/2;///sqrt(aux[0]*aux[0]+aux[1]*aux[1]+aux[2]*aux[2]+aux[3]*aux[3])*100000;  
    
    ////ILUMINACION
    vector<3> luz;
     float Ka=_material._reflective;
    vector<3> __difusa={0.5,0.5,0.5};//{1,1,0.2};
    vector<3> __especular={0.5,0.5,0.5};//{0.2,0.2,0.2}; 
    vector<3> KA={0.7,0.7,0.7};//{0.2,0.5,0.6};//{Ka,Ka,Ka};//{Ka,0,0};//{Ka,Ka,Ka};
    vector<3> KD={0.8,0.5,0.9};//{0.2,0.5,0.6};//{1,1,1};//{1,0,0};//{1,1,1};  
    vector<3> KS={1.0,1.0,1.0};//{0.2,0.5,0.6};//{1,1,1};//{1,1,1};
    luz[0]=__plights->_pos[0]-__v1[0]; 
    luz[1]=__plights->_pos[1]-__v1[1]; 
    luz[2]=__plights->_pos[2]-__v1[2];  
    //cout<<luz[0]<<" / "<<luz[1]<<" / "<<luz[2]<<endl;
    vector<3> camara; 
    camara[0]=__camera->pos()[0]-__v1[0]; 
    camara[1]=__camera->pos()[1]-__v1[1]; 
    camara[2]=__camera->pos()[2]-__v1[2]; 
    //cout<<"camara: "<<camara[0]<<" "<<camara[1]<<" "<<camara[2]<<endl;
   
    luz_phongv1= phong3(__v1,__v2,__v3,luz,camara,__ambient,KA, 
    __difusa,KD,__especular,KS,_material._shininness); 
    //cout<<"v1 "<<luz_phongv1[0]<<" "<<luz_phongv1[1]<<" "<<luz_phongv1[2]<<endl;
    /////////////
    luz[0]=__plights->_pos[0]-__v2[0]; 
    luz[1]=__plights->_pos[1]-__v2[1];  
    luz[2]=__plights->_pos[2]-__v2[2];
    camara[0]=__camera->pos()[0]-__v2[0]; 
    camara[1]=__camera->pos()[1]-__v2[1]; 
    camara[2]=__camera->pos()[2]-__v2[2]; 
    luz_phongv2= phong3(__v1,__v2,__v3,luz,camara,__ambient,KA,__difusa,KD,__especular,KS,_material._shininness);
    //cout<<"v2 "<<luz_phongv2[0]<<" "<<luz_phongv2[1]<<" "<<luz_phongv2[2]<<endl;
    /////////////
    luz[0]=__plights->_pos[0]-__v3[0];
    luz[1]=__plights->_pos[1]-__v3[1];
    luz[2]=__plights->_pos[2]-__v3[2];
    camara[0]=__camera->pos()[0]-__v3[0]; 
    camara[1]=__camera->pos()[1]-__v3[1]; 
    camara[2]=__camera->pos()[2]-__v3[2]; 
    luz_phongv3= phong3(__v1,__v2,__v3,luz,camara,__ambient,KA, __difusa,KD,__especular,KS,_material._shininness);
    //cout<<"v3 "<<luz_phongv3[0]<<" "<<luz_phongv3[1]<<" "<<luz_phongv3[2]<<endl;
    //                                                                                                                                            cout<<"AQUI "<<__pv3[0]<<" "<<__pv3[1]<<endl;
    // RELLENAR AQUI BRESENHAM para trazar  
    // las lineas entre los puntos __pv1, __pv2 y __pv3
    // Esto es: trazar la linea entre __pv1 y __pv2,
    // entre __pv1 y __pv3; y entre __pv2 y __pv30

    ////Bresenham
    list <pair<int,int > > linea;
    /*linea=bresenham(__pv1[0],__pv1[1],__pv2[0],__pv2[1]);
    linea=bresenham(__pv1[0],__pv1[1],__pv3[0],__pv3[1]);
    linea=bresenham(__pv2[0],__pv2[1],__pv3[0],__pv3[1]);*/

    //cout<<"VERTICES  "<<__pv1[0]<<" "<<__pv1[1]<<" , "<<__pv2[0]<<" "<<__pv2[1]<<" , "<<__pv3[0]<<" "<<__pv3[1]<<" "<<endl;
    /*for( auto item : linea )///pintar lo que esta en linea
    {
        vector<2> __pv_aux;
        __pv_aux[0] = item.first;
        __pv_aux[1] = item.second;
        draw_point(__pv_aux, __w, __h, __color_buffer);
    } */ 
   
    ////Scan_Line  
      
    list < vector<2> > lista; 
    pair< pair<int,int >, pair<int,int > > uno=clipping(__pv1[0],__pv1[1],__pv2[0],__pv2[1]);
        vector<2> __pva={uno.first.first,uno.first.second}; lista.push_back(__pva); //cout<<__pva[0]<<" y "<<__pva[1]<<endl;
        vector<2> __pvb={uno.second.first,uno.second.second}; lista.push_back(__pvb);//cout<<__pvb[0]<<" y "<<__pvb[1]<<endl;
    pair< pair<int,int >, pair<int,int > > dos=clipping(__pv2[0],__pv2[1],__pv3[0],__pv3[1]);
        vector<2> __pvc={dos.first.first,dos.first.second}; if(__pvb[0]!=__pvc[0]&& __pvb[1]!=__pvc[1])lista.push_back(__pvc);//cout<<__pvc[0]<<" y "<<__pvc[1]<<endl;
        vector<2> __pvd={dos.second.first,dos.second.second}; lista.push_back(__pvd);//cout<<__pvd[0]<<" y "<<__pvd[1]<<endl;
    pair< pair<int,int >, pair<int,int > > tres=clipping(__pv3[0],__pv3[1],__pv1[0],__pv1[1]);
        vector<2> __pve={tres.first.first,tres.first.second}; if(__pvd[0]!=__pve[0]&& __pvd[1]!=__pve[1]) lista.push_back(__pve);//cout<<__pve[0]<<" y "<<__pve[1]<<endl;
       // vector<2> __pvf={tres.second.first,tres.second.second}; lista.push_back(__pvf);cout<<__pvf[0]<<" y "<<__pvf[1]<<endl;
    list <pair<int,int > > pintura;   
    /*vector<2> __pv4={290,190};     
    lista.push_back(__pv4);*/
   /* lista.push_back(__pv1);
    lista.push_back(__pv2);
    lista.push_back(__pv3); 
   
    
    cout<<__pv1[0]<<" y "<<__pv1[1]<<endl;
    cout<<__pv2[0]<<" y "<<__pv2[1]<<endl;
    cout<<__pv3[0]<<" y "<<__pv3[1]<<endl;*/
    //cout<<__pv4[0]<<" y "<<__pv4[1]<<endl;
    pintura=Scan_Line(lista);
    for( auto item1 : pintura ) ///pintar lo que esta en relleno
    {
        vector<2> __pv_aux1;
        __pv_aux1[0] = item1.first;  
        __pv_aux1[1] = item1.second;   
        draw_point(__pv_aux1, __w, __h, __color_buffer,__depth_buffer);
    } 

    ///PARA ACTUALIZAR MOVIMIENTO
    relleno.clear();           
    puntos.clear();

    /*draw_point(__pv1, __w, __h, __color_buffer);
    draw_point(__pv2, __w, __h, __color_buffer);
    draw_point(__pv3, __w, __h, __color_buffer);*/

    // everything is alright
    return true;
}
//9.5 13.5 6.5
vector<3> rgb1={0.2,0.2,0.6}; 
vector<3> rgb2={0.2,0.6,0.2};
vector<3> rgb3={0.6,0.2,0.2}; 
void triangle::draw_point(vector<2> p, unsigned int __w, unsigned int __h, float*& __color_buffer, float*& __depth_buffer) {
    int __x = p[0];
    int __y = p[1];    
    vector<3> inter=interpolacion(__pv1,__pv2,__pv3,p);   
    //cout<<inter[0]<<" , "<<inter[1]<<" , "<<inter[2]<<endl;
    for(int i=0;i<4;i++)        
    {  
        if((__y * __w + __x) * 4 + i<lon && (__y * __w + __x) * 4 + i>=0)
        {   //cout<<"HERE"<<(luz_phongv1[i] +luz_phongv2[i] + luz_phongv3[i])<<endl;  
            if(i!=3)
            __color_buffer[(__y * __w + __x) * 4 + i] =inter[0]*luz_phongv1[i] + inter[1]*luz_phongv2[i] + inter[2]* luz_phongv3[i];///*(inter[i] *rgb1[i]+ inter[i]*rgb2[i]+ inter[i]*rgb3[i]);
            else
            __color_buffer[(__y * __w + __x) * 4 + i] = _material._color[i];
            
            __depth_buffer[(__y * __w + __x) * 4 + i] = inter[i]*_v1[2]+ inter[i]*_v2[2]+ inter[i]*_v3[2];
            //cout<<"Depht buuffer"<<__depth_buffer[(__y * __w + __x) * 4 + i] <<endl;
        }
        
             
    }
} 

