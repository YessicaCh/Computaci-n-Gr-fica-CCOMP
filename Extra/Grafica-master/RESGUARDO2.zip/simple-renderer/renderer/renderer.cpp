#include "renderer.h"
#include <iostream>
#include <cassert>

// constructor
renderer::renderer(object **__objects, unsigned long __num, dlight *__dlights,
        unsigned long __num_dlights, plight *__plights, unsigned long __num_plights,
        vector<3> __ambient) {
    // the objects
    _objects = __objects;
    _num = __num;

    // the directional lights
    _dlights = __dlights;
    _num_dlights = __num_dlights;

    // the positional light
    _plights = __plights;
    _num_plights = __num_plights;

    // the ambient light
    _ambient = __ambient;
}

// destructor
renderer::~renderer() {
    _objects = 0;
    _dlights = 0;
    _plights = 0;
}

// render
void renderer::render(const camera* __camera, unsigned short __w, unsigned short __h,
        float* __color) {
    camera* __mcamera = (camera*) __camera;

    // << TODO >> initialize color buffer to black
    for (register int __i = 0; __i < __w * __h * 4; __i++)
        __color[__i] = 0.f;
    int contador=0;
    int contador2=0;
    // << TODO >> create and initialize depth buffer

    // << TODO >> for each object, create and initialize temporal
    //			  color and depth buffer and call its rasterize
    //			  function and perform the corresponding
    //			  operations on the result
    
    /*float* frame_buffer;///initialize
    frame_buffer=__color;*/
    float* z_buffer;///initialize
    z_buffer = new float[ __w * __h * 4];
    for (register int __i = 0; __i < __w * __h * 4; __i++)
        z_buffer[__i] = -1.f; 

    for (register unsigned int __i = 0; __i < _num; __i++) {///for each polygon 

        float* __tcbuffer = 0;
        float* __tdbuffer = 0;
        _objects[__i]->rasterize(__mcamera, __w, __h, _ambient, _dlights, _num_dlights, _plights,
                _num_plights, __tcbuffer, __tdbuffer);

        for (register int __j = 0; __j < __w * __h * 4; __j++)///foreach pixel(x, y) in projected polygon
        {
                if(__tdbuffer[__j]>=z_buffer[__j] && __tdbuffer[__j]<=20 && __tcbuffer[__j]>__color[__j])
                {  
                    z_buffer[__j]=__tdbuffer[__j]; 
                    __color[__j] = __tcbuffer[__j];

                    //printf("%f \n",__tcbuffer[__j] );     

                        contador++;
                } 
                if(__color[__j] !=0)
                    contador2++;
           
        }    
        delete[] __tcbuffer;
        delete[] __tdbuffer; 
        
    }
    /*for (register int __j = 0; __j < __w * __h * 4; __j++)
        {
            __color[__j] = __tcbuffer[__j];
            if(__tcbuffer[__j]!=0)
            printf("HOLA %f ",__tcbuffer[__j]);
        } */  
   // printf("%d Pixeles dibujados de %lu %d \n",contador,/*__w * __h * 4*_num,*/contador2);     
    printf("%d Pixeles dibujados de %d \n   %d No dibujados\n",contador,contador2,contador2-contador); 
}
